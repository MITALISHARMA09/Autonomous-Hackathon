#!/usr/bin/env python3
"""
Complete Backend Testing Script
Run this to verify all backend functionality
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import asyncio
from app.config import get_settings
from app.database import SessionLocal, init_db
from app.models.user import User, UserRole
from app.agents.record_organizer import RecordOrganizerAgent
from app.agents.claim_processor import ClaimProcessorAgent
from app.services.llm_service import LLMService
from app.utils.helpers import (
    generate_claim_number,
    validate_abha_id,
    calculate_compliance_score
)

def print_section(title):
    """Print section header"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def test_configuration():
    """Test 1: Configuration"""
    print_section("TEST 1: Configuration")
    
    settings = get_settings()
    
    checks = {
        "App Name": settings.APP_NAME,
        "Database URL": "✓ Set" if settings.DATABASE_URL else "✗ Missing",
        "Anthropic API Key": "✓ Set" if settings.ANTHROPIC_API_KEY else "✗ Missing",
        "Secret Key": "✓ Set" if settings.SECRET_KEY else "✗ Missing",
    }
    
    for key, value in checks.items():
        print(f"  {key}: {value}")
    
    if not settings.ANTHROPIC_API_KEY:
        print("\n  ⚠️  WARNING: ANTHROPIC_API_KEY not set!")
        print("  Set it in backend/.env file")
        return False
    
    print("\n  ✅ Configuration looks good!")
    return True

def test_database():
    """Test 2: Database Connection"""
    print_section("TEST 2: Database Connection")
    
    try:
        # Initialize database
        init_db()
        print("  ✓ Database tables created/verified")
        
        # Test connection
        db = SessionLocal()
        user_count = db.query(User).count()
        print(f"  ✓ Database connected (Users: {user_count})")
        db.close()
        
        print("\n  ✅ Database working!")
        return True
        
    except Exception as e:
        print(f"  ✗ Database error: {e}")
        print("\n  ❌ Database test failed!")
        return False

def test_helpers():
    """Test 3: Helper Functions"""
    print_section("TEST 3: Helper Functions")
    
    # Test claim number generation
    claim_num = generate_claim_number()
    print(f"  ✓ Claim Number: {claim_num}")
    
    # Test ABHA validation
    valid_abha = validate_abha_id("1234-5678-9012")
    invalid_abha = validate_abha_id("invalid")
    print(f"  ✓ ABHA Validation: {valid_abha} / {not invalid_abha}")
    
    # Test compliance score
    score = calculate_compliance_score(
        has_diagnosis=True,
        has_medications=True,
        has_procedures=True,
        has_supporting_docs=True
    )
    print(f"  ✓ Compliance Score: {score}%")
    
    print("\n  ✅ Helpers working!")
    return True

def test_llm_service():
    """Test 4: LLM Service"""
    print_section("TEST 4: LLM Service (AI Agent)")
    
    try:
        llm = LLMService()
        
        # Test simple completion
        print("  Testing Claude API connection...")
        response = llm.generate_completion(
            prompt="Say 'AI connection successful' and nothing else.",
            max_tokens=50
        )
        print(f"  ✓ Claude Response: {response[:50]}...")
        
        # Test medical entity extraction
        print("\n  Testing medical entity extraction...")
        sample_text = """
        Patient presents with chest pain and shortness of breath.
        Diagnosis: Hypertension, Type 2 Diabetes
        Medications: Metoprolol 50mg twice daily, Metformin 500mg with meals
        """
        
        entities = llm.extract_medical_entities(sample_text)
        print(f"  ✓ Extracted Diagnosis: {entities.get('diagnosis', [])}")
        print(f"  ✓ Extracted Medications: {len(entities.get('medications', []))} found")
        
        # Test department classification
        print("\n  Testing department classification...")
        dept = llm.classify_department(sample_text, entities.get('diagnosis', []))
        print(f"  ✓ Classified Department: {dept}")
        
        print("\n  ✅ LLM Service working!")
        return True
        
    except Exception as e:
        print(f"  ✗ LLM Error: {e}")
        print("\n  ❌ LLM Service test failed!")
        print("  Check your ANTHROPIC_API_KEY in .env")
        return False

def test_record_organizer():
    """Test 5: Record Organizer Agent"""
    print_section("TEST 5: Record Organizer Agent")
    
    try:
        agent = RecordOrganizerAgent()
        
        sample_text = """
        Patient: John Doe
        Date: January 10, 2026
        
        Chief Complaint: Severe chest pain radiating to left arm
        
        Diagnosis:
        - Acute Myocardial Infarction
        - Hypertension
        
        Treatment:
        - Aspirin 325mg stat
        - Morphine 4mg IV
        - Nitroglycerin sublingual
        
        Procedures:
        - ECG performed
        - Troponin levels ordered
        - Admitted to CCU
        """
        
        print("  Processing medical record with AI...")
        organized = agent.organize_health_record(
            raw_text=sample_text,
            record_metadata={"source": "test"}
        )
        
        print(f"\n  ✓ Department: {organized.department}")
        print(f"  ✓ Record Type: {organized.record_type}")
        print(f"  ✓ Urgency: {organized.urgency_level}")
        print(f"  ✓ Diagnosis Count: {len(organized.diagnosis)}")
        print(f"  ✓ Medications Count: {len(organized.medications)}")
        
        print("\n  ✅ Record Organizer Agent working!")
        return True
        
    except Exception as e:
        print(f"  ✗ Agent Error: {e}")
        print("\n  ❌ Record Organizer test failed!")
        return False

def test_claim_processor():
    """Test 6: Claim Processor Agent"""
    print_section("TEST 6: Claim Processor Agent")
    
    try:
        agent = ClaimProcessorAgent()
        
        # Sample data
        health_records = [{
            "id": 1,
            "type": "consultation",
            "department": "cardiology",
            "diagnosis": ["Hypertension", "Diabetes"],
            "medications": [{"name": "Metoprolol", "dosage": "50mg"}],
            "procedures": ["ECG", "Blood Test"]
        }]
        
        patient_info = {
            "id": 1,
            "name": "Test Patient",
            "abha_id": "1234-5678-9012"
        }
        
        billing_info = {
            "total_amount": 15000,
            "currency": "INR"
        }
        
        print("  Generating claim packet with AI...")
        claim_packet = agent.generate_claim_packet(
            health_records=health_records,
            patient_info=patient_info,
            billing_info=billing_info
        )
        
        print(f"  ✓ Claim Summary: {claim_packet.claim_summary[:100]}...")
        
        print("\n  Validating claim compliance...")
        validation = agent.validate_claim(claim_packet.dict())
        print(f"  ✓ Compliance Score: {validation.compliance_score}%")
        print(f"  ✓ Is Compliant: {validation.is_compliant}")
        
        print("\n  Predicting rejection risk...")
        prediction = agent.predict_rejection_risk(claim_packet.dict())
        print(f"  ✓ Rejection Probability: {prediction.rejection_probability:.2%}")
        print(f"  ✓ Risk Factors: {len(prediction.risk_factors)} identified")
        
        print("\n  ✅ Claim Processor Agent working!")
        return True
        
    except Exception as e:
        print(f"  ✗ Agent Error: {e}")
        print("\n  ❌ Claim Processor test failed!")
        return False

def test_api_imports():
    """Test 7: API Imports"""
    print_section("TEST 7: API Module Imports")
    
    try:
        from app.api import auth, records, claims, dashboard
        print("  ✓ auth module imported")
        print("  ✓ records module imported")
        print("  ✓ claims module imported")
        print("  ✓ dashboard module imported")
        
        print("\n  ✅ All API modules import successfully!")
        return True
        
    except Exception as e:
        print(f"  ✗ Import Error: {e}")
        print("\n  ❌ API import test failed!")
        return False

def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("  HEALTH RECORD AI AGENT - BACKEND TESTS")
    print("="*60)
    
    results = {
        "Configuration": test_configuration(),
        "Database": test_database(),
        "Helpers": test_helpers(),
        "LLM Service": test_llm_service(),
        "Record Organizer": test_record_organizer(),
        "Claim Processor": test_claim_processor(),
        "API Imports": test_api_imports(),
    }
    
    # Summary
    print_section("TEST SUMMARY")
    
    passed = sum(1 for result in results.values() if result)
    total = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {test_name:.<40} {status}")
    
    print(f"\n  Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n  🎉 ALL TESTS PASSED! Backend is ready!")
        return True
    else:
        print(f"\n  ⚠️  {total - passed} test(s) failed. Check errors above.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)