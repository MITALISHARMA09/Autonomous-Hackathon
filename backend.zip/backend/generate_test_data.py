"""
Generate test data for demo purposes
Run: python generate_test_data.py
"""

import asyncio
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import random

from app.database import SessionLocal, init_db
from app.models.user import User, UserRole
from app.models.health_record import HealthRecord, RecordType, Department
from app.models.insurance_claim import InsuranceClaim, ClaimStatus
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def create_test_users(db: Session):
    """Create test users for all roles"""
    users = [
        User(
            email="patient1@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="Rajesh Kumar",
            role=UserRole.PATIENT,
            abha_id="1234-5678-9012",
            phone="+91-9876543210",
            date_of_birth=datetime(1985, 3, 15)
        ),
        User(
            email="patient2@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="Priya Sharma",
            role=UserRole.PATIENT,
            abha_id="9876-5432-1098",
            phone="+91-9123456789",
            date_of_birth=datetime(1992, 7, 22)
        ),
        User(
            email="hospital1@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="Apollo Hospitals",
            role=UserRole.HOSPITAL,
            organization_name="Apollo Hospitals Delhi",
            license_number="HOSP-2024-001"
        ),
        User(
            email="hospital2@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="Max Healthcare",
            role=UserRole.HOSPITAL,
            organization_name="Max Super Specialty Hospital",
            license_number="HOSP-2024-002"
        ),
        User(
            email="insurer1@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="Star Health Insurance",
            role=UserRole.INSURER,
            organization_name="Star Health and Allied Insurance Co.",
            license_number="INS-2024-001"
        ),
        User(
            email="insurer2@test.com",
            hashed_password=pwd_context.hash("test123"),
            full_name="HDFC ERGO",
            role=UserRole.INSURER,
            organization_name="HDFC ERGO Health Insurance",
            license_number="INS-2024-002"
        )
    ]
    
    for user in users:
        db.add(user)
    
    db.commit()
    print(f"✅ Created {len(users)} test users")
    return users

def create_test_health_records(db: Session, users: list):
    """Create sample health records"""
    patients = [u for u in users if u.role == UserRole.PATIENT]
    hospitals = [u for u in users if u.role == UserRole.HOSPITAL]
    
    records_data = [
        {
            "patient": patients[0],
            "hospital": hospitals[0],
            "record_type": RecordType.CONSULTATION,
            "department": Department.CARDIOLOGY,
            "title": "Cardiology Consultation - Hypertension",
            "description": "Patient presented with elevated blood pressure readings. Diagnosis: Essential Hypertension.",
            "diagnosis": ["Essential Hypertension", "Dyslipidemia"],
            "medications": [
                {"name": "Metoprolol", "dosage": "50mg", "frequency": "twice daily"},
                {"name": "Atorvastatin", "dosage": "20mg", "frequency": "once daily at night"}
            ],
            "procedures": ["Blood Pressure Monitoring", "ECG"],
            "visit_date": datetime.now() - timedelta(days=15)
        },
        {
            "patient": patients[0],
            "hospital": hospitals[0],
            "record_type": RecordType.LAB_REPORT,
            "department": Department.GENERAL_MEDICINE,
            "title": "Complete Blood Count & Lipid Profile",
            "description": "Routine blood work showing mild anemia and elevated cholesterol.",
            "diagnosis": ["Mild Iron Deficiency Anemia"],
            "medications": [
                {"name": "Ferrous Sulfate", "dosage": "325mg", "frequency": "once daily"}
            ],
            "procedures": ["Blood Collection", "CBC", "Lipid Profile"],
            "visit_date": datetime.now() - timedelta(days=10)
        },
        {
            "patient": patients[0],
            "hospital": hospitals[0],
            "record_type": RecordType.EMERGENCY,
            "department": Department.EMERGENCY,
            "title": "Emergency Visit - Chest Pain",
            "description": "Patient presented with acute chest pain. Ruled out MI. Diagnosis: GERD.",
            "diagnosis": ["Gastroesophageal Reflux Disease"],
            "medications": [
                {"name": "Omeprazole", "dosage": "40mg", "frequency": "once daily before breakfast"},
                {"name": "Antacid", "dosage": "10ml", "frequency": "as needed"}
            ],
            "procedures": ["ECG", "Troponin Test", "Chest X-Ray"],
            "visit_date": datetime.now() - timedelta(days=5)
        },
        {
            "patient": patients[1],
            "hospital": hospitals[1],
            "record_type": RecordType.DISCHARGE_SUMMARY,
            "department": Department.ORTHOPEDICS,
            "title": "Discharge Summary - Knee Arthroscopy",
            "description": "Successful arthroscopic meniscus repair. Patient stable and discharged.",
            "diagnosis": ["Meniscus Tear - Right Knee"],
            "medications": [
                {"name": "Ibuprofen", "dosage": "400mg", "frequency": "every 6 hours"},
                {"name": "Cephalexin", "dosage": "500mg", "frequency": "every 8 hours for 5 days"}
            ],
            "procedures": ["Arthroscopic Meniscus Repair", "Post-op monitoring"],
            "visit_date": datetime.now() - timedelta(days=20)
        },
        {
            "patient": patients[1],
            "hospital": hospitals[1],
            "record_type": RecordType.RADIOLOGY,
            "department": Department.ORTHOPEDICS,
            "title": "MRI - Right Knee",
            "description": "MRI imaging shows medial meniscus tear. Recommended surgical intervention.",
            "diagnosis": ["Medial Meniscus Tear"],
            "medications": [],
            "procedures": ["MRI Knee"],
            "visit_date": datetime.now() - timedelta(days=25)
        }
    ]
    
    records = []
    for data in records_data:
        record = HealthRecord(
            patient_id=data["patient"].id,
            hospital_id=data["hospital"].id,
            record_type=data["record_type"],
            department=data["department"],
            title=data["title"],
            description=data["description"],
            diagnosis=data["diagnosis"],
            medications=data["medications"],
            procedures=data["procedures"],
            visit_date=data["visit_date"],
            extracted_data={
                "ai_processed": True,
                "confidence_score": random.uniform(0.85, 0.98)
            }
        )
        records.append(record)
        db.add(record)
    
    db.commit()
    print(f"✅ Created {len(records)} test health records")
    return records

def create_test_claims(db: Session, users: list, records: list):
    """Create sample insurance claims"""
    patients = [u for u in users if u.role == UserRole.PATIENT]
    hospitals = [u for u in users if u.role == UserRole.HOSPITAL]
    insurers = [u for u in users if u.role == UserRole.INSURER]
    
    claims_data = [
        {
            "claim_number": "CLM-A1B2C3D4",
            "patient": patients[0],
            "hospital": hospitals[0],
            "insurer": insurers[0],
            "claim_amount": 45000,
            "approved_amount": 42000,
            "status": ClaimStatus.APPROVED,
            "compliance_score": 94.5,
            "rejection_risk": 0.12,
            "submitted_at": datetime.now() - timedelta(days=12),
            "approved_at": datetime.now() - timedelta(days=5)
        },
        {
            "claim_number": "CLM-E5F6G7H8",
            "patient": patients[0],
            "hospital": hospitals[0],
            "insurer": insurers[1],
            "claim_amount": 28000,
            "approved_amount": None,
            "status": ClaimStatus.UNDER_REVIEW,
            "compliance_score": 88.3,
            "rejection_risk": 0.25,
            "submitted_at": datetime.now() - timedelta(days=3),
            "approved_at": None
        },
        {
            "claim_number": "CLM-I9J0K1L2",
            "patient": patients[1],
            "hospital": hospitals[1],
            "insurer": insurers[0],
            "claim_amount": 125000,
            "approved_amount": 118000,
            "status": ClaimStatus.APPROVED,
            "compliance_score": 91.7,
            "rejection_risk": 0.18,
            "submitted_at": datetime.now() - timedelta(days=25),
            "approved_at": datetime.now() - timedelta(days=15),
            "settled_at": datetime.now() - timedelta(days=10)
        },
        {
            "claim_number": "CLM-M3N4O5P6",
            "patient": patients[1],
            "hospital": hospitals[1],
            "insurer": None,
            "claim_amount": 15000,
            "approved_amount": None,
            "status": ClaimStatus.DRAFT,
            "compliance_score": 78.5,
            "rejection_risk": 0.45,
            "submitted_at": None,
            "approved_at": None
        }
    ]
    
    for data in claims_data:
        claim = InsuranceClaim(
            claim_number=data["claim_number"],
            patient_id=data["patient"].id,
            hospital_id=data["hospital"].id,
            insurer_id=data["insurer"].id if data["insurer"] else None,
            claim_amount=data["claim_amount"],
            approved_amount=data["approved_amount"],
            status=data["status"],
            compliance_score=data["compliance_score"],
            rejection_risk=data["rejection_risk"],
            submitted_at=data["submitted_at"],
            approved_at=data["approved_at"],
            settled_at=data.get("settled_at"),
            ai_recommendations=[
                "All required documents attached",
                "Procedure codes verified",
                "Medical necessity established"
            ] if data["compliance_score"] > 85 else [
                "Consider adding discharge summary",
                "Verify procedure codes",
                "Additional medical justification needed"
            ]
        )
        db.add(claim)
    
    db.commit()
    print(f"✅ Created {len(claims_data)} test insurance claims")

def main():
    print("🏥 Generating Test Data for Health Record AI Agent")
    print("=" * 50)
    
    # Initialize database
    init_db()
    db = SessionLocal()
    
    try:
        # Create test data
        users = create_test_users(db)
        records = create_test_health_records(db, users)
        create_test_claims(db, users, records)
        
        print("\n" + "=" * 50)
        print("✅ Test data generation complete!")
        print("\nTest Users Created:")
        print("  Patient 1: patient1@test.com / test123")
        print("  Patient 2: patient2@test.com / test123")
        print("  Hospital 1: hospital1@test.com / test123")
        print("  Hospital 2: hospital2@test.com / test123")
        print("  Insurer 1: insurer1@test.com / test123")
        print("  Insurer 2: insurer2@test.com / test123")
        print("\n🚀 You can now start the application and login!")
        
    except Exception as e:
        print(f"\n❌ Error generating test data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    main()