"""
Health Record Pydantic Schemas
"""
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime

class HealthRecordCreate(BaseModel):
    patient_id: int
    hospital_id: int
    record_type: str
    title: str
    description: Optional[str] = None
    visit_date: Optional[datetime] = None

class HealthRecordResponse(BaseModel):
    id: int
    patient_id: int
    hospital_id: Optional[int]
    record_type: str
    department: Optional[str]
    title: str
    description: Optional[str]
    diagnosis: Optional[List[str]]
    medications: Optional[List[Dict]]
    procedures: Optional[List[str]]
    extracted_data: Optional[Dict[str, Any]]
    visit_date: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True

class HealthRecordUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    diagnosis: Optional[List[str]] = None
    medications: Optional[List[Dict]] = None