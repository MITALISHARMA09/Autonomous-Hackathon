"""
Insurance Claim Pydantic Schemas
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

class ClaimCreate(BaseModel):
    patient_id: int
    hospital_id: int
    record_ids: List[int]
    claim_amount: float = Field(..., gt=0)

class ClaimResponse(BaseModel):
    id: int
    claim_number: str
    patient_id: int
    hospital_id: int
    insurer_id: Optional[int]
    claim_amount: float
    approved_amount: Optional[float]
    settled_amount: Optional[float]
    status: str
    compliance_score: Optional[float]
    rejection_risk: Optional[float]
    ai_recommendations: Optional[List[str]]
    submitted_at: Optional[datetime]
    approved_at: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True

class ClaimStatusUpdate(BaseModel):
    status: str  # "submitted", "under_review", "approved", "rejected", "settled"
    approved_amount: Optional[float] = None
    rejection_reason: Optional[str] = None

class ClaimPacketResponse(BaseModel):
    claim_id: int
    claim_number: str
    claim_packet: Dict[str, Any]
    validation: Dict[str, Any]
    risk_assessment: Dict[str, Any]