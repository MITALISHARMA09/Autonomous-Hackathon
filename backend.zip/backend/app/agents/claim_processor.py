from langchain_anthropic import ChatAnthropic
from langchain.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from app.config import get_settings
import json

settings = get_settings()

class ClaimValidation(BaseModel):
    is_compliant: bool = Field(description="Whether claim meets compliance requirements")
    compliance_score: float = Field(description="Score 0-100")
    missing_documents: List[str] = Field(description="List of missing required documents")
    errors: List[str] = Field(description="List of compliance errors")
    warnings: List[str] = Field(description="List of warnings")

class RejectionPrediction(BaseModel):
    rejection_probability: float = Field(description="Probability of rejection 0-1")
    risk_factors: List[str] = Field(description="Factors increasing rejection risk")
    recommendations: List[str] = Field(description="Recommendations to improve approval chances")

class ClaimPacket(BaseModel):
    claim_summary: str
    patient_details: Dict
    treatment_summary: Dict
    itemized_billing: List[Dict]
    supporting_evidence: List[str]
    compliance_checklist: Dict

class ClaimProcessorAgent:
    def __init__(self):
        self.llm = ChatAnthropic(
            model=settings.MODEL_NAME,
            anthropic_api_key=settings.ANTHROPIC_API_KEY,
            temperature=0.1
        )
    
    def generate_claim_packet(
        self, 
        health_records: List[Dict],
        patient_info: Dict,
        billing_info: Dict
    ) -> ClaimPacket:
        """
        Generate complete insurance claim packet from health records
        """
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert insurance claim processing AI agent for Indian health insurance.
            
            Your task is to generate a complete, compliant insurance claim packet that includes:
            1. Comprehensive claim summary
            2. Patient demographic and medical history
            3. Treatment details with clinical justification
            4. Itemized billing with ICD-10 and procedure codes
            5. All required supporting documentation references
            6. Compliance checklist for IRDAI guidelines
            
            Ensure the packet is ready for submission to insurance companies."""),
            ("user", """Generate insurance claim packet:
            
            Health Records:
            {health_records}
            
            Patient Information:
            {patient_info}
            
            Billing Details:
            {billing_info}
            
            Return structured JSON claim packet.""")
        ])
        
        chain = prompt | self.llm
        
        result = chain.invoke({
            "health_records": json.dumps(health_records, indent=2),
            "patient_info": json.dumps(patient_info, indent=2),
            "billing_info": json.dumps(billing_info, indent=2)
        })
        
        try:
            packet_data = json.loads(result.content)
            return ClaimPacket(**packet_data)
        except:
            return self._create_fallback_packet(health_records, patient_info, billing_info)
    
    def validate_claim(self, claim_packet: Dict) -> ClaimValidation:
        """
        Validate claim for compliance with insurance requirements
        """
        prompt = f"""Validate this insurance claim packet for compliance:
        
        {json.dumps(claim_packet, indent=2)}
        
        Check for:
        - All required documents present
        - Proper ICD-10 coding
        - Treatment justification
        - Billing accuracy
        - IRDAI compliance
        
        Return JSON:
        {{
            "is_compliant": true/false,
            "compliance_score": 0-100,
            "missing_documents": [],
            "errors": [],
            "warnings": []
        }}"""
        
        result = self.llm.invoke(prompt)
        
        try:
            validation = json.loads(result.content)
            return ClaimValidation(**validation)
        except:
            return ClaimValidation(
                is_compliant=False,
                compliance_score=50.0,
                missing_documents=["Unable to validate"],
                errors=["Validation error"],
                warnings=[]
            )
    
    def predict_rejection_risk(
        self,
        claim_packet: Dict,
        historical_data: Optional[List[Dict]] = None
    ) -> RejectionPrediction:
        """
        Predict likelihood of claim rejection using AI analysis
        """
        prompt = f"""Analyze this insurance claim and predict rejection risk:
        
        Claim:
        {json.dumps(claim_packet, indent=2)}
        
        Based on common rejection reasons:
        - Incomplete documentation
        - Non-covered procedures
        - Pre-existing condition clauses
        - Billing discrepancies
        - Lack of medical necessity
        
        Return JSON:
        {{
            "rejection_probability": 0.0-1.0,
            "risk_factors": ["list of risks"],
            "recommendations": ["list of improvements"]
        }}"""
        
        result = self.llm.invoke(prompt)
        
        try:
            prediction = json.loads(result.content)
            return RejectionPrediction(**prediction)
        except:
            return RejectionPrediction(
                rejection_probability=0.3,
                risk_factors=["Unable to assess"],
                recommendations=["Manual review recommended"]
            )
    
    def optimize_claim(self, claim_packet: Dict) -> Dict:
        """
        AI-powered claim optimization to maximize approval chances
        """
        prompt = f"""Optimize this insurance claim to maximize approval probability:
        
        {json.dumps(claim_packet, indent=2)}
        
        Provide:
        1. Improved clinical justification
        2. Better documentation mapping
        3. Optimized billing codes
        4. Stronger supporting evidence
        
        Return the optimized claim packet as JSON."""
        
        result = self.llm.invoke(prompt)
        
        try:
            return json.loads(result.content)
        except:
            return claim_packet
    
    def _create_fallback_packet(self, records, patient, billing) -> ClaimPacket:
        """Fallback claim packet if AI generation fails"""
        return ClaimPacket(
            claim_summary="Medical treatment claim",
            patient_details=patient,
            treatment_summary={"records": len(records)},
            itemized_billing=[],
            supporting_evidence=[],
            compliance_checklist={}
        )