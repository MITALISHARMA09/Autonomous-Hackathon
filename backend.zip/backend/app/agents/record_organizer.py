from langchain_anthropic import ChatAnthropic
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from app.config import get_settings
import json

settings = get_settings()

class MedicalEntity(BaseModel):
    type: str = Field(description="Type of entity: diagnosis, medication, procedure, vitals")
    value: str = Field(description="The extracted value")
    confidence: float = Field(description="Confidence score 0-1")

class OrganizedRecord(BaseModel):
    department: str = Field(description="Medical department classification")
    record_type: str = Field(description="Type of medical record")
    diagnosis: List[str] = Field(description="List of diagnoses")
    medications: List[Dict] = Field(description="List of medications with dosage")
    procedures: List[str] = Field(description="List of procedures performed")
    vitals: Dict = Field(description="Patient vitals if available")
    summary: str = Field(description="Brief clinical summary")
    urgency_level: str = Field(description="low, medium, high, critical")

class RecordOrganizerAgent:
    def __init__(self):
        self.llm = ChatAnthropic(
            model=settings.MODEL_NAME,
            anthropic_api_key=settings.ANTHROPIC_API_KEY,
            temperature=0.1
        )
        self.parser = PydanticOutputParser(pydantic_object=OrganizedRecord)
    
    def organize_health_record(self, raw_text: str, record_metadata: dict) -> OrganizedRecord:
        """
        Main agent function to organize and structure health records
        """
        prompt = ChatPromptTemplate.from_messages([
            ("system", """You are an expert medical AI agent specialized in organizing health records 
            for the Indian healthcare system (ABDM/ABHA compliant).
            
            Your tasks:
            1. Classify the medical department
            2. Extract diagnosis, medications, procedures
            3. Identify record type (consultation, lab report, discharge summary, etc.)
            4. Assess urgency level
            5. Create a structured summary
            
            Return valid JSON matching the schema.
            
            {format_instructions}"""),
            ("user", """Analyze this medical record:
            
            Raw Text:
            {raw_text}
            
            Metadata:
            {metadata}
            
            Provide structured output.""")
        ])
        
        chain = prompt | self.llm
        
        result = chain.invoke({
            "raw_text": raw_text,
            "metadata": json.dumps(record_metadata),
            "format_instructions": self.parser.get_format_instructions()
        })
        
        # Parse the result
        try:
            organized = self.parser.parse(result.content)
            return organized
        except Exception as e:
            # Fallback parsing
            return self._fallback_parse(result.content)
    
    def _fallback_parse(self, content: str) -> OrganizedRecord:
        """Fallback parser if structured parsing fails"""
        return OrganizedRecord(
            department="general_medicine",
            record_type="consultation",
            diagnosis=["Unable to parse"],
            medications=[],
            procedures=[],
            vitals={},
            summary=content[:500],
            urgency_level="medium"
        )
    
    def classify_department(self, symptoms: List[str], diagnosis: List[str]) -> str:
        """AI-powered department classification"""
        prompt = f"""Given these symptoms: {symptoms} and diagnosis: {diagnosis},
        classify the appropriate medical department from:
        cardiology, neurology, orthopedics, general_medicine, pediatrics, oncology, emergency, icu
        
        Return only the department name."""
        
        result = self.llm.invoke(prompt)
        return result.content.strip().lower()
    
    def extract_entities(self, text: str) -> List[MedicalEntity]:
        """Extract medical entities using NER-like approach"""
        prompt = f"""Extract medical entities from this text:
        {text}
        
        Return as JSON list with format:
        [{{"type": "diagnosis", "value": "Hypertension", "confidence": 0.95}}]
        
        Types: diagnosis, medication, procedure, vital_sign"""
        
        result = self.llm.invoke(prompt)
        
        try:
            entities = json.loads(result.content)
            return [MedicalEntity(**e) for e in entities]
        except:
            return []