"""
Notification Service
Handles email, SMS, and in-app notifications
Mock implementation for hackathon
"""
from typing import Dict, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class NotificationService:
    """
    Mock notification service for demonstration
    In production, integrate with email (SendGrid) and SMS (Twilio) services
    """
    
    def __init__(self):
        self.sent_notifications = []  # Store for demo purposes
    
    async def send_email(
        self, 
        to: str, 
        subject: str, 
        body: str,
        html: bool = False
    ) -> bool:
        """
        Send email notification
        Mock implementation - logs instead of sending
        """
        notification = {
            "type": "email",
            "to": to,
            "subject": subject,
            "body": body,
            "timestamp": datetime.now().isoformat(),
            "status": "sent"
        }
        
        self.sent_notifications.append(notification)
        logger.info(f"📧 Email notification: {subject} to {to}")
        
        # In production:
        # Use SendGrid, AWS SES, or similar
        # await email_client.send(to=to, subject=subject, body=body)
        
        return True
    
    async def send_sms(self, phone: str, message: str) -> bool:
        """
        Send SMS notification
        Mock implementation
        """
        notification = {
            "type": "sms",
            "to": phone,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "status": "sent"
        }
        
        self.sent_notifications.append(notification)
        logger.info(f"📱 SMS notification: {message[:50]}... to {phone}")
        
        # In production:
        # Use Twilio, AWS SNS, or similar
        # await sms_client.send(to=phone, message=message)
        
        return True
    
    async def notify_claim_status_change(
        self,
        user_email: str,
        user_phone: str,
        claim_number: str,
        old_status: str,
        new_status: str
    ) -> bool:
        """
        Notify user about claim status change
        """
        subject = f"Claim {claim_number} Status Update"
        message = f"Your insurance claim {claim_number} status changed from {old_status} to {new_status}"
        
        # Send both email and SMS
        await self.send_email(user_email, subject, message)
        await self.send_sms(user_phone, message)
        
        return True
    
    async def notify_record_uploaded(
        self,
        user_email: str,
        record_title: str
    ) -> bool:
        """
        Notify user that health record was uploaded and processed
        """
        subject = "Health Record Processed Successfully"
        body = f"""
        Your health record "{record_title}" has been successfully uploaded and processed by our AI system.
        
        You can view the organized record in your dashboard.
        
        - Health Record AI Team
        """
        
        await self.send_email(user_email, subject, body)
        return True
    
    async def notify_claim_generated(
        self,
        user_email: str,
        claim_number: str,
        compliance_score: float
    ) -> bool:
        """
        Notify user that claim was generated
        """
        subject = f"Insurance Claim {claim_number} Generated"
        body = f"""
        Your insurance claim has been generated successfully.
        
        Claim Number: {claim_number}
        AI Compliance Score: {compliance_score}%
        
        You can submit this claim from your dashboard.
        
        - Health Record AI Team
        """
        
        await self.send_email(user_email, subject, body)
        return True
    
    async def notify_hospital_claim_approved(
        self,
        hospital_email: str,
        claim_number: str,
        approved_amount: float
    ) -> bool:
        """
        Notify hospital that claim was approved
        """
        subject = f"Claim {claim_number} Approved"
        body = f"""
        Insurance claim has been approved.
        
        Claim Number: {claim_number}
        Approved Amount: ₹{approved_amount:,.2f}
        
        Settlement will be processed within 5-7 business days.
        
        - Health Record AI Team
        """
        
        await self.send_email(hospital_email, subject, body)
        return True
    
    async def send_bulk_notifications(
        self,
        recipients: List[str],
        subject: str,
        message: str
    ) -> Dict:
        """
        Send notifications to multiple recipients
        """
        results = {
            "total": len(recipients),
            "sent": 0,
            "failed": 0
        }
        
        for recipient in recipients:
            try:
                await self.send_email(recipient, subject, message)
                results["sent"] += 1
            except Exception as e:
                logger.error(f"Failed to send to {recipient}: {e}")
                results["failed"] += 1
        
        return results
    
    def get_notification_history(self, user_email: str = None) -> List[Dict]:
        """
        Get notification history
        For demo purposes
        """
        if user_email:
            return [n for n in self.sent_notifications if n.get("to") == user_email]
        return self.sent_notifications