"""
LLM Service - Centralized Claude API interactions
"""
from anthropic import Anthropic
from typing import Dict, List, Optional
import json
from app.config import get_settings

settings = get_settings()

class LLMService:
    """
    Centralized service for all LLM interactions
    """
    
    def __init__(self):
        self.client = Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = settings.MODEL_NAME
    
    def generate_completion(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 2000,
        temperature: float = 0.1
    ) -> str:
        """
        Generate completion from Claude
        """
        messages = [{"role": "user", "content": prompt}]
        
        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages
        }
        
        if system_prompt:
            kwargs["system"] = system_prompt
        
        response = self.client.messages.create(**kwargs)
        return response.content[0].text
    
    def extract_medical_entities(self, text: str) -> Dict:
        """
        Extract structured medical information from text
        """
        system_prompt = """You are a medical AI assistant specializing in extracting structured 
        information from medical documents. Extract and return JSON with these fields:
        - diagnosis: list of diagnoses
        - medications: list of medications with dosage
        - procedures: list of procedures
        - vitals: dict of vital signs if present
        """
        
        prompt = f"""Extract medical information from this text and return as JSON:

{text}

Return valid JSON only, no additional text."""
        
        try:
            response = self.generate_completion(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.1
            )
            
            # Clean response
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            response = response.strip()
            
            return json.loads(response)
        except json.JSONDecodeError:
            # Return empty structure if parsing fails
            return {
                "diagnosis": [],
                "medications": [],
                "procedures": [],
                "vitals": {}
            }
    
    def classify_department(self, text: str, diagnosis: List[str]) -> str:
        """
        Classify medical department based on text and diagnosis
        """
        prompt = f"""Based on this medical information, classify the appropriate department:

Text: {text[:500]}
Diagnosis: {', '.join(diagnosis)}

Choose from: cardiology, neurology, orthopedics, general_medicine, pediatrics, 
oncology, emergency, icu, dermatology, gastroenterology

Return only the department name, nothing else."""
        
        response = self.generate_completion(prompt=prompt, max_tokens=50)
        return response.strip().lower()
    
    def assess_urgency(self, text: str, diagnosis: List[str]) -> str:
        """
        Assess urgency level of medical case
        """
        prompt = f"""Assess the urgency level of this medical case:

Text: {text[:500]}
Diagnosis: {', '.join(diagnosis)}

Return only one word: low, medium, high, or critical"""
        
        response = self.generate_completion(prompt=prompt, max_tokens=20)
        urgency = response.strip().lower()
        
        # Validate response
        valid_levels = ["low", "medium", "high", "critical"]
        return urgency if urgency in valid_levels else "medium"
    
    def generate_summary(self, text: str, max_length: int = 200) -> str:
        """
        Generate clinical summary from medical text
        """
        prompt = f"""Summarize this medical information in {max_length} characters or less:

{text}

Summary:"""
        
        response = self.generate_completion(
            prompt=prompt,
            max_tokens=100,
            temperature=0.3
        )
        
        return response.strip()[:max_length]
    
    def validate_claim_compliance(self, claim_data: Dict) -> Dict:
        """
        Validate insurance claim for compliance
        """
        prompt = f"""Review this insurance claim for compliance with Indian health insurance standards:

{json.dumps(claim_data, indent=2)}

Return JSON with:
- is_compliant: boolean
- compliance_score: 0-100
- missing_documents: list
- errors: list
- warnings: list

Return valid JSON only."""
        
        try:
            response = self.generate_completion(
                prompt=prompt,
                system_prompt="You are an insurance compliance expert for Indian health insurance.",
                max_tokens=1000
            )
            
            # Clean and parse
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            
            return json.loads(response.strip())
        except:
            return {
                "is_compliant": True,
                "compliance_score": 75.0,
                "missing_documents": [],
                "errors": [],
                "warnings": ["Auto-validation pending"]
            }
    
    def predict_rejection_risk(self, claim_data: Dict) -> Dict:
        """
        Predict likelihood of claim rejection
        """
        prompt = f"""Analyze this insurance claim and predict rejection risk:

{json.dumps(claim_data, indent=2)}

Return JSON with:
- rejection_probability: 0.0 to 1.0
- risk_factors: list of strings
- recommendations: list of strings

Return valid JSON only."""
        
        try:
            response = self.generate_completion(
                prompt=prompt,
                max_tokens=800
            )
            
            # Clean and parse
            response = response.strip()
            if response.startswith("```json"):
                response = response[7:]
            if response.endswith("```"):
                response = response[:-3]
            
            return json.loads(response.strip())
        except:
            return {
                "rejection_probability": 0.3,
                "risk_factors": ["Unable to assess automatically"],
                "recommendations": ["Manual review recommended"]
            }