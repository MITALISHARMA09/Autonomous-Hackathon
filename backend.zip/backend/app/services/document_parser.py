from PyPDF2 import PdfReader
from docx import Document
from io import BytesIO
from PIL import Image
import pytesseract
from typing import Union

class DocumentParser:
    """
    Service to parse various document formats for health records
    """
    
    def parse_document(self, content: bytes, filename: str) -> str:
        """
        Parse document and extract text based on file type
        """
        if filename.endswith('.pdf'):
            return self._parse_pdf(content)
        elif filename.endswith(('.docx', '.doc')):
            return self._parse_docx(content)
        elif filename.endswith(('.png', '.jpg', '.jpeg')):
            return self._parse_image(content)
        else:
            # Treat as plain text
            return content.decode('utf-8', errors='ignore')
    
    def _parse_pdf(self, content: bytes) -> str:
        """Extract text from PDF"""
        try:
            pdf_file = BytesIO(content)
            pdf_reader = PdfReader(pdf_file)
            
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            
            return text.strip()
        except Exception as e:
            return f"Error parsing PDF: {str(e)}"
    
    def _parse_docx(self, content: bytes) -> str:
        """Extract text from DOCX"""
        try:
            doc_file = BytesIO(content)
            doc = Document(doc_file)
            
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            
            return text.strip()
        except Exception as e:
            return f"Error parsing DOCX: {str(e)}"
    
    def _parse_image(self, content: bytes) -> str:
        """Extract text from image using OCR"""
        try:
            image = Image.open(BytesIO(content))
            text = pytesseract.image_to_string(image)
            return text.strip()
        except Exception as e:
            return f"Error parsing image: {str(e)}"