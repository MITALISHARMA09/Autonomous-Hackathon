from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, JSON, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum

class RecordType(str, enum.Enum):
    CONSULTATION = "consultation"
    LAB_REPORT = "lab_report"
    PRESCRIPTION = "prescription"
    DISCHARGE_SUMMARY = "discharge_summary"
    RADIOLOGY = "radiology"
    SURGERY = "surgery"

class Department(str, enum.Enum):
    CARDIOLOGY = "cardiology"
    NEUROLOGY = "neurology"
    ORTHOPEDICS = "orthopedics"
    GENERAL_MEDICINE = "general_medicine"
    PEDIATRICS = "pediatrics"
    ONCOLOGY = "oncology"
    EMERGENCY = "emergency"
    ICU = "icu"

class HealthRecord(Base):
    __tablename__ = "health_records"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    hospital_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    record_type = Column(Enum(RecordType), nullable=False)
    department = Column(Enum(Department), nullable=True)
    
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    
    # AI-extracted structured data
    extracted_data = Column(JSON, nullable=True)
    diagnosis = Column(JSON, nullable=True)
    medications = Column(JSON, nullable=True)
    procedures = Column(JSON, nullable=True)
    
    # Document storage
    document_url = Column(String, nullable=True)
    file_hash = Column(String, nullable=True)
    
    # ABHA integration
    abha_record_id = Column(String, unique=True, nullable=True)
    consent_status = Column(String, default="pending")
    
    visit_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    patient = relationship("User", foreign_keys=[patient_id])
    hospital = relationship("User", foreign_keys=[hospital_id])