from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float, Enum, JSON, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum

class ClaimStatus(str, enum.Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    SETTLED = "settled"

class InsuranceClaim(Base):
    __tablename__ = "insurance_claims"
    
    id = Column(Integer, primary_key=True, index=True)
    claim_number = Column(String, unique=True, nullable=False, index=True)
    
    patient_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    hospital_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    insurer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # Claim details
    claim_amount = Column(Float, nullable=False)
    approved_amount = Column(Float, nullable=True)
    settled_amount = Column(Float, nullable=True)
    
    status = Column(Enum(ClaimStatus), default=ClaimStatus.DRAFT)
    
    # Associated health records
    health_record_ids = Column(JSON, nullable=True)  # List of record IDs
    
    # AI-generated claim packet
    claim_packet = Column(JSON, nullable=True)
    supporting_documents = Column(JSON, nullable=True)
    
    # Validation & prediction
    compliance_score = Column(Float, nullable=True)
    rejection_risk = Column(Float, nullable=True)
    ai_recommendations = Column(JSON, nullable=True)
    
    # Processing timeline
    submitted_at = Column(DateTime, nullable=True)
    reviewed_at = Column(DateTime, nullable=True)
    approved_at = Column(DateTime, nullable=True)
    settled_at = Column(DateTime, nullable=True)
    
    # Rejection details
    rejection_reason = Column(Text, nullable=True)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    patient = relationship("User", foreign_keys=[patient_id])
    hospital = relationship("User", foreign_keys=[hospital_id])
    insurer = relationship("User", foreign_keys=[insurer_id])