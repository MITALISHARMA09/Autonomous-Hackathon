"""
Helper Utility Functions
"""
import uuid
import re
from datetime import datetime, timedelta
from typing import Optional

def generate_claim_number() -> str:
    """
    Generate unique claim number
    Format: CLM-XXXXXXXX
    """
    return f"CLM-{uuid.uuid4().hex[:8].upper()}"

def calculate_processing_time(
    submitted_at: datetime,
    approved_at: Optional[datetime] = None
) -> int:
    """
    Calculate processing time in days
    """
    if not approved_at:
        approved_at = datetime.now()
    
    delta = approved_at - submitted_at
    return delta.days

def format_currency(amount: float, currency: str = "INR") -> str:
    """
    Format currency for display
    """
    if currency == "INR":
        # Indian numbering system
        return f"₹{amount:,.2f}"
    else:
        return f"{currency} {amount:,.2f}"

def validate_abha_id(abha_id: str) -> bool:
    """
    Validate ABHA ID format
    Format: XXXX-XXXX-XXXX (12 digits with hyphens)
    """
    pattern = r'^\d{4}-\d{4}-\d{4}$'
    return bool(re.match(pattern, abha_id))

def validate_phone(phone: str) -> bool:
    """
    Validate Indian phone number
    """
    # Remove any non-digit characters
    digits = re.sub(r'\D', '', phone)
    
    # Check if it's 10 digits (Indian mobile) or 12 digits (with country code)
    return len(digits) in [10, 12]

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe storage
    """
    # Remove any characters that aren't alphanumeric, dash, underscore, or dot
    sanitized = re.sub(r'[^\w\-.]', '_', filename)
    return sanitized

def generate_record_id() -> str:
    """
    Generate unique record ID
    """
    return f"REC-{uuid.uuid4().hex[:12].upper()}"

def calculate_compliance_score(
    has_diagnosis: bool,
    has_medications: bool,
    has_procedures: bool,
    has_supporting_docs: bool,
    icd_codes_present: bool = False
) -> float:
    """
    Calculate claim compliance score (0-100)
    """
    score = 0.0
    
    # Base requirements
    if has_diagnosis:
        score += 30
    if has_medications:
        score += 20
    if has_procedures:
        score += 20
    if has_supporting_docs:
        score += 20
    if icd_codes_present:
        score += 10
    
    return min(score, 100.0)

def estimate_rejection_risk(
    compliance_score: float,
    missing_documents: int,
    patient_history: Optional[dict] = None
) -> float:
    """
    Estimate rejection risk (0.0 to 1.0)
    """
    # Base risk from compliance
    risk = (100 - compliance_score) / 100
    
    # Increase risk for missing documents
    risk += (missing_documents * 0.1)
    
    # Factor in patient history if available
    if patient_history:
        if patient_history.get("previous_rejections", 0) > 0:
            risk += 0.1
        if patient_history.get("claim_count", 0) > 10:
            risk -= 0.05  # Lower risk for established patients
    
    # Ensure risk is between 0 and 1
    return max(0.0, min(1.0, risk))

def format_medical_date(date: datetime) -> str:
    """
    Format date for medical records
    """
    return date.strftime("%d %B %Y")

def parse_date_string(date_str: str) -> Optional[datetime]:
    """
    Parse various date formats
    """
    formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%d/%m/%Y",
        "%Y/%m/%d",
        "%d %B %Y",
        "%B %d, %Y"
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    
    return None

def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate text to specified length
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix

def generate_file_hash(content: bytes) -> str:
    """
    Generate hash for file content (for deduplication)
    """
    import hashlib
    return hashlib.sha256(content).hexdigest()

def is_weekend(date: datetime) -> bool:
    """
    Check if date is weekend
    """
    return date.weekday() >= 5  # Saturday=5, Sunday=6

def add_business_days(start_date: datetime, days: int) -> datetime:
    """
    Add business days (excluding weekends)
    """
    current = start_date
    added = 0
    
    while added < days:
        current += timedelta(days=1)
        if not is_weekend(current):
            added += 1
    
    return current