from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    # App Settings
    APP_NAME: str = "Health Record AI Agent"
    VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Database
    DATABASE_URL: str = "postgresql://user:password@localhost:5432/health_records"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # AI/LLM
    ANTHROPIC_API_KEY: str = ""
    MODEL_NAME: str = "claude-sonnet-4-20250514"
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-this-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    
    # GCP
    GCP_PROJECT_ID: str = ""
    GCP_BUCKET_NAME: str = "health-records-storage"
    
    # ABHA Integration (Mock for hackathon)
    ABHA_API_URL: str = "https://abha-mock-api.example.com"
    ABHA_CLIENT_ID: str = ""
    ABHA_CLIENT_SECRET: str = ""
    
    # CORS
    CORS_ORIGINS: list = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://localhost:8080"
    ]
    
    class Config:
        env_file = ".env"
        case_sensitive = True

@lru_cache()
def get_settings():
    return Settings()