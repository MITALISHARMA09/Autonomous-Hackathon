"""
API Routes Package
"""
from fastapi import APIRouter

# This file can be empty or used for route aggregation
# Individual routes are imported in main.py

__all__ = []