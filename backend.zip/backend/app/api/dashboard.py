from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Dict, List
from datetime import datetime, timedelta

from app.database import get_db
from app.models.health_record import HealthRecord, Department
from app.models.insurance_claim import InsuranceClaim, ClaimStatus
from app.models.user import User
from app.api.auth import get_current_user

router = APIRouter()

@router.get("/patient/{patient_id}/stats")
async def get_patient_stats(
    patient_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get patient dashboard statistics"""
    
    # Total records
    total_records = db.query(HealthRecord).filter(
        HealthRecord.patient_id == patient_id
    ).count()
    
    # Active claims
    active_claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.patient_id == patient_id,
        InsuranceClaim.status.in_([ClaimStatus.SUBMITTED, ClaimStatus.UNDER_REVIEW])
    ).count()
    
    # Departments visited
    departments = db.query(HealthRecord.department).filter(
        HealthRecord.patient_id == patient_id,
        HealthRecord.department.isnot(None)
    ).distinct().count()
    
    # Average processing time for approved claims
    approved_claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.patient_id == patient_id,
        InsuranceClaim.status == ClaimStatus.APPROVED,
        InsuranceClaim.submitted_at.isnot(None),
        InsuranceClaim.approved_at.isnot(None)
    ).all()
    
    avg_processing_days = 0
    if approved_claims:
        total_days = sum([
            (c.approved_at - c.submitted_at).days 
            for c in approved_claims
        ])
        avg_processing_days = total_days // len(approved_claims)
    
    return {
        "total_records": total_records,
        "active_claims": active_claims,
        "departments_visited": departments,
        "avg_processing_days": avg_processing_days
    }

@router.get("/hospital/{hospital_id}/stats")
async def get_hospital_stats(
    hospital_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get hospital dashboard statistics"""
    
    # All claims
    all_claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.hospital_id == hospital_id
    ).all()
    
    total_claims = len(all_claims)
    
    # Status breakdown
    pending_claims = sum(1 for c in all_claims if c.status in [
        ClaimStatus.SUBMITTED, ClaimStatus.UNDER_REVIEW
    ])
    approved_claims = sum(1 for c in all_claims if c.status == ClaimStatus.APPROVED)
    rejected_claims = sum(1 for c in all_claims if c.status == ClaimStatus.REJECTED)
    
    # Financial stats
    total_amount = sum(c.claim_amount for c in all_claims)
    approved_amount = sum(c.approved_amount or 0 for c in all_claims)
    
    # Average processing time
    processed_claims = [c for c in all_claims if c.approved_at and c.submitted_at]
    avg_processing_time = 0
    if processed_claims:
        total_days = sum([(c.approved_at - c.submitted_at).days for c in processed_claims])
        avg_processing_time = total_days // len(processed_claims)
    
    # Claims by department
    claims_by_dept = db.query(
        HealthRecord.department,
        func.count(InsuranceClaim.id).label('count'),
        func.sum(InsuranceClaim.claim_amount).label('amount')
    ).join(
        HealthRecord,
        InsuranceClaim.health_record_ids.contains([HealthRecord.id])
    ).filter(
        InsuranceClaim.hospital_id == hospital_id
    ).group_by(HealthRecord.department).all()
    
    department_stats = [
        {
            "department": dept.value if dept else "other",
            "claims": count,
            "amount": float(amount) if amount else 0
        }
        for dept, count, amount in claims_by_dept
    ]
    
    return {
        "total_claims": total_claims,
        "pending_claims": pending_claims,
        "approved_claims": approved_claims,
        "rejected_claims": rejected_claims,
        "total_amount": total_amount,
        "approved_amount": approved_amount,
        "avg_processing_time": avg_processing_time,
        "approval_rate": (approved_claims / total_claims * 100) if total_claims > 0 else 0,
        "claims_by_department": department_stats
    }

@router.get("/hospital/{hospital_id}/trends")
async def get_hospital_trends(
    hospital_id: int,
    months: int = 6,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get claim trends for hospital"""
    
    start_date = datetime.now() - timedelta(days=months * 30)
    
    claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.hospital_id == hospital_id,
        InsuranceClaim.created_at >= start_date
    ).all()
    
    # Group by month
    trends = {}
    for claim in claims:
        month_key = claim.created_at.strftime("%Y-%m")
        if month_key not in trends:
            trends[month_key] = {
                "submitted": 0,
                "approved": 0,
                "rejected": 0
            }
        
        trends[month_key]["submitted"] += 1
        if claim.status == ClaimStatus.APPROVED:
            trends[month_key]["approved"] += 1
        elif claim.status == ClaimStatus.REJECTED:
            trends[month_key]["rejected"] += 1
    
    return {
        "trends": [
            {
                "month": month,
                **data
            }
            for month, data in sorted(trends.items())
        ]
    }

@router.get("/insurer/{insurer_id}/stats")
async def get_insurer_stats(
    insurer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get insurer dashboard statistics"""
    
    claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.insurer_id == insurer_id
    ).all()
    
    total_claims = len(claims)
    pending_review = sum(1 for c in claims if c.status == ClaimStatus.UNDER_REVIEW)
    auto_approved = sum(1 for c in claims if c.compliance_score and c.compliance_score > 90)
    
    # Fraud flags (high rejection risk)
    fraud_flagged = sum(1 for c in claims if c.rejection_risk and c.rejection_risk > 0.7)
    
    # Time saved (assuming manual processing takes 2 hours per claim)
    time_saved_hours = total_claims * 2 * 0.7  # 70% time reduction
    
    return {
        "total_claims": total_claims,
        "pending_review": pending_review,
        "auto_approved": auto_approved,
        "fraud_flagged": fraud_flagged,
        "time_saved_hours": int(time_saved_hours)
    }