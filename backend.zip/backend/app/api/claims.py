from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
import uuid

from app.database import get_db
from app.models.insurance_claim import InsuranceClaim, ClaimStatus
from app.models.health_record import HealthRecord
from app.models.user import User
from app.agents.claim_processor import ClaimProcessorAgent

router = APIRouter()
claim_agent = ClaimProcessorAgent()

@router.post("/generate")
async def generate_claim(
    patient_id: int,
    hospital_id: int,
    record_ids: List[int],
    claim_amount: float,
    db: Session = Depends(get_db)
):
    """
    Generate insurance claim using AI agent
    """
    try:
        # Fetch health records
        records = db.query(HealthRecord).filter(
            HealthRecord.id.in_(record_ids)
        ).all()
        
        if not records:
            raise HTTPException(status_code=404, detail="No health records found")
        
        # Fetch patient info
        patient = db.query(User).filter(User.id == patient_id).first()
        if not patient:
            raise HTTPException(status_code=404, detail="Patient not found")
        
        # Prepare data for AI agent
        health_records_data = [
            {
                "id": r.id,
                "type": r.record_type.value,
                "department": r.department.value if r.department else None,
                "diagnosis": r.diagnosis,
                "medications": r.medications,
                "procedures": r.procedures,
                "visit_date": r.visit_date.isoformat() if r.visit_date else None
            }
            for r in records
        ]
        
        patient_info = {
            "id": patient.id,
            "name": patient.full_name,
            "abha_id": patient.abha_id,
            "dob": patient.date_of_birth.isoformat() if patient.date_of_birth else None
        }
        
        billing_info = {
            "total_amount": claim_amount,
            "currency": "INR"
        }
        
        # Generate claim packet using AI
        claim_packet = claim_agent.generate_claim_packet(
            health_records=health_records_data,
            patient_info=patient_info,
            billing_info=billing_info
        )
        
        # Validate claim
        validation = claim_agent.validate_claim(claim_packet.dict())
        
        # Predict rejection risk
        prediction = claim_agent.predict_rejection_risk(claim_packet.dict())
        
        # Create claim in database
        claim = InsuranceClaim(
            claim_number=f"CLM-{uuid.uuid4().hex[:8].upper()}",
            patient_id=patient_id,
            hospital_id=hospital_id,
            claim_amount=claim_amount,
            status=ClaimStatus.DRAFT,
            health_record_ids=record_ids,
            claim_packet=claim_packet.dict(),
            compliance_score=validation.compliance_score,
            rejection_risk=prediction.rejection_probability,
            ai_recommendations=prediction.recommendations
        )
        
        db.add(claim)
        db.commit()
        db.refresh(claim)
        
        return {
            "success": True,
            "claim_id": claim.id,
            "claim_number": claim.claim_number,
            "status": claim.status.value,
            "claim_packet": claim_packet.dict(),
            "validation": validation.dict(),
            "risk_assessment": prediction.dict(),
            "message": "Insurance claim generated successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating claim: {str(e)}")

@router.post("/{claim_id}/submit")
async def submit_claim(claim_id: int, insurer_id: int, db: Session = Depends(get_db)):
    """
    Submit claim to insurance company
    """
    claim = db.query(InsuranceClaim).filter(InsuranceClaim.id == claim_id).first()
    
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    
    if claim.status != ClaimStatus.DRAFT:
        raise HTTPException(status_code=400, detail="Claim already submitted")
    
    # Update claim status
    claim.status = ClaimStatus.SUBMITTED
    claim.insurer_id = insurer_id
    claim.submitted_at = datetime.now()
    
    db.commit()
    
    return {
        "success": True,
        "claim_number": claim.claim_number,
        "status": claim.status.value,
        "submitted_at": claim.submitted_at.isoformat()
    }

@router.get("/{claim_id}/status")
async def get_claim_status(claim_id: int, db: Session = Depends(get_db)):
    """
    Get real-time claim status and timeline
    """
    claim = db.query(InsuranceClaim).filter(InsuranceClaim.id == claim_id).first()
    
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    
    # Calculate processing time
    timeline = {
        "submitted": claim.submitted_at.isoformat() if claim.submitted_at else None,
        "reviewed": claim.reviewed_at.isoformat() if claim.reviewed_at else None,
        "approved": claim.approved_at.isoformat() if claim.approved_at else None,
        "settled": claim.settled_at.isoformat() if claim.settled_at else None
    }
    
    return {
        "claim_number": claim.claim_number,
        "status": claim.status.value,
        "claim_amount": claim.claim_amount,
        "approved_amount": claim.approved_amount,
        "settled_amount": claim.settled_amount,
        "compliance_score": claim.compliance_score,
        "rejection_risk": claim.rejection_risk,
        "timeline": timeline,
        "ai_recommendations": claim.ai_recommendations
    }

@router.get("/patient/{patient_id}")
async def get_patient_claims(patient_id: int, db: Session = Depends(get_db)):
    """
    Get all claims for a patient
    """
    claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.patient_id == patient_id
    ).order_by(InsuranceClaim.created_at.desc()).all()
    
    return {
        "total": len(claims),
        "claims": [
            {
                "id": c.id,
                "claim_number": c.claim_number,
                "status": c.status.value,
                "claim_amount": c.claim_amount,
                "approved_amount": c.approved_amount,
                "compliance_score": c.compliance_score,
                "rejection_risk": c.rejection_risk,
                "created_at": c.created_at.isoformat()
            }
            for c in claims
        ]
    }

@router.get("/hospital/{hospital_id}")
async def get_hospital_claims(hospital_id: int, db: Session = Depends(get_db)):
    """
    Get all claims for a hospital
    """
    claims = db.query(InsuranceClaim).filter(
        InsuranceClaim.hospital_id == hospital_id
    ).order_by(InsuranceClaim.created_at.desc()).all()
    
    # Calculate statistics
    total_amount = sum(c.claim_amount for c in claims)
    approved_amount = sum(c.approved_amount or 0 for c in claims)
    
    status_count = {}
    for claim in claims:
        status = claim.status.value
        status_count[status] = status_count.get(status, 0) + 1
    
    return {
        "total_claims": len(claims),
        "total_claim_amount": total_amount,
        "total_approved_amount": approved_amount,
        "status_breakdown": status_count,
        "claims": [
            {
                "id": c.id,
                "claim_number": c.claim_number,
                "patient_id": c.patient_id,
                "status": c.status.value,
                "claim_amount": c.claim_amount,
                "compliance_score": c.compliance_score,
                "created_at": c.created_at.isoformat()
            }
            for c in claims[:50]  # Return latest 50
        ]
    }