from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import json

from app.database import get_db
from app.models.health_record import HealthRecord, RecordType, Department
from app.models.user import User
from app.agents.record_organizer import RecordOrganizerAgent
from app.services.document_parser import DocumentParser

router = APIRouter()
organizer_agent = RecordOrganizerAgent()
doc_parser = DocumentParser()

@router.post("/upload")
async def upload_health_record(
    file: UploadFile = File(...),
    patient_id: int = 1,
    hospital_id: int = 2,
    db: Session = Depends(get_db)
):
    """
    Upload and process health record using AI agent
    """
    try:
        # Read file content
        content = await file.read()
        
        # Parse document (PDF, DOCX, or image)
        parsed_text = doc_parser.parse_document(content, file.filename)
        
        # Use AI agent to organize the record
        organized = organizer_agent.organize_health_record(
            raw_text=parsed_text,
            record_metadata={
                "filename": file.filename,
                "upload_date": datetime.now().isoformat()
            }
        )
        
        # Create database record
        health_record = HealthRecord(
            patient_id=patient_id,
            hospital_id=hospital_id,
            record_type=RecordType(organized.record_type),
            department=Department(organized.department),
            title=f"{organized.record_type.title()} - {datetime.now().strftime('%Y-%m-%d')}",
            description=organized.summary,
            extracted_data={
                "raw_text": parsed_text[:1000],  # Store first 1000 chars
                "urgency": organized.urgency_level
            },
            diagnosis=organized.diagnosis,
            medications=organized.medications,
            procedures=organized.procedures,
            visit_date=datetime.now()
        )
        
        db.add(health_record)
        db.commit()
        db.refresh(health_record)
        
        return {
            "success": True,
            "record_id": health_record.id,
            "organized_data": organized.dict(),
            "message": "Health record processed and organized successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing record: {str(e)}")

@router.get("/patient/{patient_id}")
async def get_patient_records(
    patient_id: int,
    department: Optional[str] = None,
    record_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get all health records for a patient with optional filtering
    """
    query = db.query(HealthRecord).filter(HealthRecord.patient_id == patient_id)
    
    if department:
        query = query.filter(HealthRecord.department == department)
    if record_type:
        query = query.filter(HealthRecord.record_type == record_type)
    
    records = query.order_by(HealthRecord.visit_date.desc()).all()
    
    return {
        "total": len(records),
        "records": [
            {
                "id": r.id,
                "title": r.title,
                "department": r.department.value if r.department else None,
                "record_type": r.record_type.value,
                "visit_date": r.visit_date.isoformat() if r.visit_date else None,
                "diagnosis": r.diagnosis,
                "medications": r.medications,
                "summary": r.description
            }
            for r in records
        ]
    }

@router.get("/{record_id}")
async def get_record_detail(record_id: int, db: Session = Depends(get_db)):
    """
    Get detailed information about a specific health record
    """
    record = db.query(HealthRecord).filter(HealthRecord.id == record_id).first()
    
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    
    return {
        "id": record.id,
        "title": record.title,
        "description": record.description,
        "department": record.department.value if record.department else None,
        "record_type": record.record_type.value,
        "diagnosis": record.diagnosis,
        "medications": record.medications,
        "procedures": record.procedures,
        "extracted_data": record.extracted_data,
        "visit_date": record.visit_date.isoformat() if record.visit_date else None,
        "created_at": record.created_at.isoformat()
    }

@router.get("/department-summary/{patient_id}")
async def get_department_summary(patient_id: int, db: Session = Depends(get_db)):
    """
    Get organized summary of records by department
    """
    records = db.query(HealthRecord).filter(
        HealthRecord.patient_id == patient_id
    ).all()
    
    # Organize by department
    dept_summary = {}
    for record in records:
        dept = record.department.value if record.department else "general"
        if dept not in dept_summary:
            dept_summary[dept] = {
                "count": 0,
                "recent_visit": None,
                "diagnoses": set(),
                "medications": []
            }
        
        dept_summary[dept]["count"] += 1
        if record.visit_date:
            if not dept_summary[dept]["recent_visit"] or record.visit_date > dept_summary[dept]["recent_visit"]:
                dept_summary[dept]["recent_visit"] = record.visit_date.isoformat()
        
        if record.diagnosis:
            dept_summary[dept]["diagnoses"].update(record.diagnosis)
    
    # Convert sets to lists for JSON serialization
    for dept in dept_summary:
        dept_summary[dept]["diagnoses"] = list(dept_summary[dept]["diagnoses"])
    
    return dept_summary